package smu.db_project.spend;

public class SpendRepository {

}
