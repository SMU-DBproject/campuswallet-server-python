## 1차 작업
Oracle Cloud에 Oracle DB 올리고 Spring 연동




## 2차 작업
Entity 작성 및 파일 구조 정리


